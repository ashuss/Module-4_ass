package com.capgemini.question.dao;

import com.capgemini.question.bean.Question;

public interface IQuestionDAO {
	public Question addQuestion(Question question);
}
