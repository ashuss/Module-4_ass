/**
 * 
 */
package com.capgemini.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.trainee.beans.Trainee;

/**
 * @author Lalita
 *
 */
@Repository
@Transactional
public class TraineeDao implements ITraineeDao {
	@PersistenceContext
private EntityManager entityManager;
	/* (non-Javadoc)
	 * @see com.capgemini.trainee.dao.ITraineeDao#addtrainee(com.capgemini.trainee.beans.Trainee)
	 */
	@Override
	public Trainee addTrainee(Trainee trainee) {
		System.out.println(trainee);
		entityManager.persist(trainee);//adding the donor obj to db
		entityManager.flush();
		return trainee;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.trainee.dao.ITraineeDao#gettraineeDetails(int)
	 */
	@Override
	public Trainee getTraineeDetails(int traineeId) {
		return entityManager.find(Trainee.class, traineeId);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.trainee.dao.ITraineeDao#getAllDonorsDetails()
	 */
	@Override
	public List<Trainee> getAllTraineeDetails() {
		TypedQuery<Trainee> query = 
				entityManager.createQuery("SELECT d FROM Trainee d", 
						Trainee.class);
		return query.getResultList();
	}

}
