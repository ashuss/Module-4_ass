package com.capgemini.trainee.dao;

import java.util.List;

import com.capgemini.trainee.beans.Trainee;

public interface ITraineeDao {
	public Trainee addTrainee(Trainee trainee);

	public Trainee getTraineeDetails(int traineeId);

	public List<Trainee> getAllTraineeDetails();
	
}
