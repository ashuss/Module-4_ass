package com.capgemini.trainee.service;

import java.util.List;

import com.capgemini.trainee.beans.Trainee;

public interface ITraineeService {

	public Trainee addTrainee(Trainee trainee);

	public Trainee getTraineeDetails(int traineeId);

	public List<Trainee> getAllTraineeDetails();

}
