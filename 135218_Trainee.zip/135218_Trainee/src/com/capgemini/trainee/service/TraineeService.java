/**
 * 
 */
package com.capgemini.trainee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.trainee.beans.Trainee;
import com.capgemini.trainee.dao.ITraineeDao;

/**
 * @author Lalita
 *
 */
@Service
public class TraineeService implements ITraineeService {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.capgemini.trainee.service.ITraineeService#addTrainee(com.capgemini
	 * .trainee.beans.Trainee)
	 */
	@Autowired
	ITraineeDao traineeDao;

	

	public ITraineeDao getTraineeDao() {
		return traineeDao;
	}

	public void setTraineeDao(ITraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

	@Override
	public Trainee addTrainee(Trainee trainee) {
		
		return traineeDao.addTrainee(trainee);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.trainee.service.ITraineeService#getTraineeDetails(int)
	 */
	@Override
	public Trainee getTraineeDetails(int traineeId) {

		return traineeDao.getTraineeDetails(traineeId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.trainee.service.ITraineeService#getAllTraineeDetails()
	 */
	@Override
	public List<Trainee> getAllTraineeDetails() {
		return traineeDao.getAllTraineeDetails();
	}

}
