/**
 * 
 */
package com.capgemini.trainee.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.trainee.beans.Login;
import com.capgemini.trainee.beans.Trainee;
import com.capgemini.trainee.service.ITraineeService;

/**
 * @author Lalita
 *
 */
@Scope("session")
@Controller
public class TraineeController {
	@Autowired
	private ITraineeService traineeService;

	public ITraineeService getTraineeService() {
		return traineeService;
	}

	public void setTraineeService(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}

	@RequestMapping("/showHomePage")
	public String showForm(Model model) { // LogicBean-logicbean
		model.addAttribute("login", new Login());// login model
		return "springLogin"; // logical view name

	}

	@RequestMapping("/checkLogin")
	public String checkLogin(Login login, Model model) {
		model.addAttribute("login", login);
		return "index";
	}
	@RequestMapping("/showTraineeForm")
	public ModelAndView showAddDonation() {
		// Create an attribute of type Question
		Trainee trainee = new Trainee();
		// Add the attribute to the model and set the viewname and return it
		return new ModelAndView("addDonationForm", "trainee", trainee);
	}
	
	@RequestMapping("/addDonation")
	/*public String addDonation(@ModelAttribute("trainee") ){
		trainee = traineeService.addTrainee(trainee);
		return "success";
	}*/
	public ModelAndView addDonation(
			@ModelAttribute("trainee") @Valid Trainee trainee,
			BindingResult result) {
		ModelAndView mv = null;
		if (!result.hasErrors()) {
			trainee = traineeService.addTrainee(trainee);
			mv=new ModelAndView("index");
		} else {
			mv = new ModelAndView("addDonationForm", "trainee", trainee);
			System.out.println(mv);
		}
		return mv;//returning mv obj
	}
	@RequestMapping("/showViewTraineeForm")
	public ModelAndView showViewDonationForm() {
		// Create an attribute of type Question
		Trainee trainee = new Trainee();
		// Add the attribute to the model and return along with the view name
		ModelAndView mv = new ModelAndView("viewDonation");
		mv.addObject("trainee", trainee);
		mv.addObject("isFirst", "true");
		return mv;
	}
	@RequestMapping("/viewDonation")
	public ModelAndView viewDonation(@ModelAttribute("trainee") Trainee trainee) {
		ModelAndView mv = new ModelAndView();
		Trainee dtrainee = new Trainee();
		dtrainee = traineeService.getTraineeDetails(trainee.getTraineeId());
		if (dtrainee != null) {
			mv.setViewName("viewDonation");
			mv.addObject("dtrainee", dtrainee);
		} else {
			String msg = "Enter a Valid Id!!";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}
		return mv;
	}

	@RequestMapping("/showViewAllTrainees")
	public ModelAndView showViewAllDonations() {

		ModelAndView mv = new ModelAndView();
		List<Trainee> list = traineeService.getAllTraineeDetails();
		if (list.isEmpty()) {
			String msg = "There are no Donors";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		} else {
			mv.setViewName("viewAllDonorsList");
			// Add the attribute to the model
			mv.addObject("list", list);
		}
		return mv;
}
}