package com.capgemini.schedule.exception;


//exception class
public class ScheduleException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4330085985672205704L;

	public ScheduleException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ScheduleException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	
}
