package com.capgemini.schedule.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.schedule.beans.ScheduledSessions;
import com.capgemini.schedule.exception.ScheduleException;
import com.capgemini.schedule.service.ITrainingService;


//controller class
@Controller
public class TrainingController {

	ArrayList<String> roleList;
	
	@Autowired
	ITrainingService serviceObj; //service object

	@RequestMapping("/showHomePage") //control will come here to display the first page when the project runs
	public String showHomePage(Model mv) {
		ArrayList<ScheduledSessions> scheduleList;
		try {
			scheduleList = (ArrayList<ScheduledSessions>)serviceObj.getScheduleList(); //calls getScheduleList() from service layer
		} catch (ScheduleException e) {
			mv.addAttribute("error", e.getMessage());
			return "error";
		}
		mv.addAttribute("scheduleList", scheduleList);
		return "ScheduledSessions"; //displays JSP page
	}
	
	@RequestMapping("/updateId") //control will come here to display the update form 
	
	public ModelAndView showModifyForm(@ModelAttribute("session") ScheduledSessions scheduledSessions,@RequestParam("id") String id){
		roleList = new ArrayList<String>(); //list of roles to be populated
		roleList.add("ILT");
		roleList.add("VC");
		roleList.add("WBT");
		
		ModelAndView mv=new ModelAndView();
		mv.setViewName("UpdateSession"); //will go to UpdateSession.jsp
		int id1=Integer.parseInt(id); //converting parameter id(received from form) to int
		ScheduledSessions sBean=serviceObj.getUpdateForm(id1); //calls getUpdateForm from service layer
		//adding objects to the model
		mv.addObject("name",sBean.getName());
		mv.addObject("duration",sBean.getDuration());
		mv.addObject("faculty",sBean.getFaculty());
		mv.addObject("roleList", roleList);
		return mv;
	}
}
