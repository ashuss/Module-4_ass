package com.capgemini.schedule.service;

import java.util.List;

import com.capgemini.schedule.beans.ScheduledSessions;
import com.capgemini.schedule.exception.ScheduleException;

public interface ITrainingService {
	List<ScheduledSessions> getScheduleList() throws ScheduleException ;
	ScheduledSessions getUpdateForm(int id);
}
