package com.capgemini.schedule.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.schedule.beans.ScheduledSessions;
import com.capgemini.schedule.dao.ITrainingDAO;
import com.capgemini.schedule.exception.ScheduleException;

@Service("serviceObj")
@Transactional
public class TrainingServiceImpl implements ITrainingService {
	
	@Autowired
	ITrainingDAO daoObj;
	
	//------------------------ Session Schedule Management --------------------------
		/*******************************************************************************************************
		 - Function Name	:	getScheduleList
		 - Throws		    :  	ScheduleException
		 - Creation Date	:	12/10/2017
		 - Description		:	calls dao method getScheduleList()
		 ********************************************************************************************************/
		

	@Override
	public List<ScheduledSessions> getScheduleList() throws ScheduleException {
		// TODO Auto-generated method stub
		return daoObj.getScheduleList();
	}
	
	//------------------------ Session Schedule Management --------------------------
		/*******************************************************************************************************
		 - Function Name	:	getUpdateForm
		 - Creation Date	:	12/10/2017
		 - Description		:	calls dao method getUpdateForm()
		 ********************************************************************************************************/


		@Override
		public ScheduledSessions getUpdateForm(int id) {
			// TODO Auto-generated method stub
			return daoObj.getUpdateForm(id);
		}

}
