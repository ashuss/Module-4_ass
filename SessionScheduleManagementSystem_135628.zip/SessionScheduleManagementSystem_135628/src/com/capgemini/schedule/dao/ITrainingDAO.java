package com.capgemini.schedule.dao;

//DAO
import java.util.List;

import com.capgemini.schedule.beans.ScheduledSessions;
import com.capgemini.schedule.exception.ScheduleException;

public interface ITrainingDAO {
	List<ScheduledSessions> getScheduleList() throws ScheduleException ;
	ScheduledSessions getUpdateForm(int id);

}
