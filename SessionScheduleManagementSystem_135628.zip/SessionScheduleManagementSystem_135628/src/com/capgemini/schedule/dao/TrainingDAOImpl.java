package com.capgemini.schedule.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.schedule.beans.ScheduledSessions;
import com.capgemini.schedule.exception.ScheduleException;

@Repository
public class TrainingDAOImpl implements ITrainingDAO {
	
	//EntityManager creation
	@PersistenceContext
	EntityManager entityManager;
	List<ScheduledSessions> scheduleList=null;

	//------------------------ Session Schedule Management --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getScheduleList
			 - Throws		    :  	ScheduleException
			 - Creation Date	:	12/10/2017
			 - Description		:	runs query to retrieve all data from database
			 ********************************************************************************************************/
			
	@Override
	public List<ScheduledSessions> getScheduleList() throws ScheduleException {
		// TODO Auto-generated method stub
		try
		{
			String qu="from ScheduledSessions";
			TypedQuery<ScheduledSessions> query=entityManager.createQuery(qu,ScheduledSessions.class);
			scheduleList=query.getResultList();	
		}
		catch(Exception ex) {
			throw new ScheduleException(ex.getMessage());
		}
		System.out.println(scheduleList);
		return scheduleList;
	}

	//------------------------ Session Schedule Management --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getUpdateForm
	 - Creation Date	:	12/10/2017
	 - Description		:	finds data from database based on the id
	 ********************************************************************************************************/
	
	@Override
	public ScheduledSessions getUpdateForm(int id) {
		// TODO Auto-generated method stub
		ScheduledSessions schedule=entityManager.find(ScheduledSessions.class, id);
		return schedule;
	}

}
