package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.Employee;

public interface IEmpService {

	List<String> getDesigList();

	int addEmployeeDetails(Employee emp);

	List<Employee> getAllEmployees();

}
