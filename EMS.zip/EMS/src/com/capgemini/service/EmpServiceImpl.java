package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.bean.Employee;
import com.capgemini.dao.IEmpDao;

@Transactional
@Service
public class EmpServiceImpl implements IEmpService {

	@Autowired
	private IEmpDao empDao;
	@Override
	public List<String> getDesigList() {
		return empDao.getDesigList();
	}
	@Override
	public int addEmployeeDetails(Employee emp) {
		return empDao.addEmployeeDetails(emp);
	}
	@Override
	public List<Employee> getAllEmployees() {
		return empDao.getAllEmployees();
	}

}
