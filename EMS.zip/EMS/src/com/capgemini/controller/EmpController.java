package com.capgemini.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.bean.Employee;
import com.capgemini.service.IEmpService;

@Controller
public class EmpController {

	@Autowired
	private IEmpService empService;
	
	@RequestMapping("addEmp.obj")
	public String addEmployee(Model model) {
		System.out.println("add employee..");
		Employee emp = new Employee();
		List<String> desigList = empService.getDesigList();
		model.addAttribute("newemp", emp);
		model.addAttribute("dlist", desigList);
		return "newEmp";		
	}
	@RequestMapping("goHome.obj")
	public String goToHomePage(Model model) {
		return "index";
	}

	@RequestMapping("submitEmp.obj")
	public String submitEmployee
	    (@ModelAttribute (value="newemp")@Valid Employee emp, 
			  BindingResult bresult, Model model) {
		System.out.println("submit Emplyoee...");
		if(bresult.hasErrors()) {
			List<String> desigList = empService.getDesigList();
			model.addAttribute("dlist", desigList);
			return "newEmp";
		}
		else {
			int empid = empService.addEmployeeDetails(emp);
			if(empid!=0) {
				model.addAttribute("eid", empid);
				return "submitSuccess";	
			}
		}
		return "submitFail";		
	}
	@RequestMapping("showEmp.obj")
	public String getAllEmployees(Model model) {
		List<Employee> eList = null;
		eList = empService.getAllEmployees();
		model.addAttribute("elist", eList);
		return "empList";
	}

}
