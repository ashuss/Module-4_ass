package com.capgemini.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="emp_hib_cg")
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@NotEmpty(message="Enter the name")
	@Pattern(regexp="[A-Z][A-Za-z]+", 
	 message="Name should start with uppercase and only alphabets")
	private String name;
	@NotEmpty(message="Select a gender")
	private String gender;
	@NotEmpty(message="Select a designation")
	@Pattern(regexp = "^(?:(?!Select).)*$", message = "Select a category")
	private String designation;
	@NotEmpty(message="Enter email id")
	@Pattern(regexp="^[a-zA-Z-0-9-\\_\\+\\.)]+@[(a-zA-Z)]+\\.[(a-zA-Z)]{2,3}$",
	  message="Email should be in proper format")
	private String email;
	@NotEmpty(message="Please Enter Employee Phone")
	@Pattern(regexp = "^[789][0-9]{9}+$", message = "Phone should start with 7,8 or 9 and 10 digits")
	private String phone;
	public Employee() {
	}
	public Employee(int id, String name, String gender, String designation, String email, String phone) {
		super();
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.designation = designation;
		this.email = email;
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", gender=" + gender + ", designation=" + designation
				+ ", email=" + email + ", phone=" + phone + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
