package com.capgemini.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.bean.Employee;

@Transactional
@Repository
public class EmpDao implements IEmpDao {

	@PersistenceContext
	EntityManager eManager;
	
	@Override
	public List<String> getDesigList() {
		List<String> desigList = new ArrayList<>();
		desigList.add("Software Engineer");
		desigList.add("Senior Software Engineer");
		desigList.add("Team Lead");
		desigList.add("Manager");
		return desigList;		
	}

	@Override
	public int addEmployeeDetails(Employee emp) {
		int eid = 0;
		try {
		   eManager.persist(emp);
		   eid = emp.getId();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return eid;
	}

	@Override
	public List<Employee> getAllEmployees() {
		String qry = "select e from Employee e";
		try {
		TypedQuery<Employee> tQuery = 
				eManager.createQuery(qry, Employee.class);
		return tQuery.getResultList();
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}		
	}

}
