package com.capgemini.dao;

import java.util.List;

import com.capgemini.bean.Employee;

public interface IEmpDao {

	List<String> getDesigList();

	int addEmployeeDetails(Employee emp);

	List<Employee> getAllEmployees();

}
