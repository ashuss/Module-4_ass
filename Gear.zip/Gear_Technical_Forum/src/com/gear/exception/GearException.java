package com.gear.exception;

public class GearException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3788218863485754025L;
	public GearException(){
		super();
	}
	
	public GearException(String message){
		super(message);
	}

}
