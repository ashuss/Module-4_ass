package com.gear.dao;

import com.gear.bean.Gear;
import com.gear.exception.GearException;

public interface IGearDao {
	public Gear view(int queryId)throws GearException;
	
	public boolean update(Gear gear)throws GearException; 
}
