/**
 * 
 */
package com.capgemini.product.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.product.bean.Product;


/**
 * @author Lalita
 *
 */
@Repository
@Transactional
//marking dao with @Repository spring annotation and javax @Transactional
public class ProductDaoImpl implements IProductDao {
	//creating  EntityManager instance and mark it with @PersistenceContext
	@PersistenceContext
	private EntityManager entityManager;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.product.dao.IProductDao#productList()
	 */
	//------------------------ 1. Product Book --------------------------
			/*******************************************************************************************************
				 - Function Name	:	productList(List<Product>)
				 - Query type	    :   TypedQuery<Product>(dynamic type)
				 - Return Type		:	List<Product> using getResultList
				 - Throws		    :   ProductException
				 - Author		    :    Lalita Suresh Gawas
				 - Creation Date	:	12/10/2017
				 - Description		: Fetching Details from table Product 
			 ********************************************************************************************************/
	@Override
	public List<Product> productList() {
		TypedQuery<Product> query = entityManager.createQuery(
				"SELECT p FROM Product p", Product.class);
		return query.getResultList();
		
	}
	//------------------------ 2. Product Book --------------------------
	/*******************************************************************************************************
		 - Function Name	:	deleteProduct(List<Product>)
		 -Input Parameter   :   int id
		 - Query type	    :   TypedQuery<Product>(dynamic type)
		 - Return Type		:	List<Product> using getResultList
		 - Throws		    :   ProductException
		 - Author		    :     Lalita Suresh Gawas
		 - Creation Date	:	12/10/2017
		 - Description		: Deleting Details from table Product 
	 ********************************************************************************************************/
	@Override
	public List<Product> deleteProduct(int id) {
Product product=entityManager.find(Product.class, id); //first find that product according to id
entityManager.remove(product);  //then remove
TypedQuery<Product> query = entityManager.createQuery(
		"SELECT p FROM Product p", Product.class);  //retriving current table details after deleting using TypedQuery
return query.getResultList();

		
	}

}
