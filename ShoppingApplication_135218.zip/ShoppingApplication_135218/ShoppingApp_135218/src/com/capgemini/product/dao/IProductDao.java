/**************************************************************
File Name   :IProductDao.java
Author      :Lalita Gawas
Description :Inteface for ProductDaoImpl with 2 methods defined one for retriving 
              productlist and second for deletion of product from Product. 
Date        :12/10/2017
***************************************************************/
package com.capgemini.product.dao;

import java.util.List;

import com.capgemini.product.bean.Product;

/**
 * @author Lalita
 *
 */
public interface IProductDao {
	//------------------------ 1. Product Book --------------------------
	/*******************************************************************************************************
		 - Function Name	:	productList(List<Product>)
		 - Query type	    :   TypedQuery<Product>(dynamic type)
		 - Return Type		:	List<Product>
		 - Throws		    :   ProductException
		 - Author		    :     Lalita Suresh Gawas
		 - Creation Date	:	12/10/2017
		 - Description		: Fetching Details from table Product 
	 ********************************************************************************************************/
	public List<Product> productList();
	
	//------------------------ 2. Product Book --------------------------
		/*******************************************************************************************************
			 - Function Name	:	deleteProduct(List<Product>)
			 -Input Parameter   :   int id
			 - Query type	    :   TypedQuery<Product>(dynamic type)
			 - Return Type		:	List<Product> using getResultList
			 - Throws		    :   ProductException
			 - Author		    :     Lalita Suresh Gawas
			 - Creation Date	:	12/10/2017
			 - Description		: Deleting Details from table Product 
		 ********************************************************************************************************/

	public List<Product> deleteProduct(int id);
}
