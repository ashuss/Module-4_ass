/**************************************************************
File Name   : Product.java
Author      :Lalita Gawas
Description : Setter,Getter methods for class Product 
Date        :12/10/2017
 ***************************************************************/
package com.capgemini.product.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Lalita
 *
 */
//public bean & marking the bean with @Entity and @Table
@Entity
@Table(name = "Product")
public class Product {
	//private properties with @column Annotations 
		//default & overloaded 
	@Id
	@Column(name = "product_id")
	private int productId;
	@Column(name = "product_name")
	private String productName;
	@Column(name = "product_price")
	private int productPrice;
	@Column(name = "product_quantity")
	private int productQuantity;
	@Column(name = "description")
	private String description;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName="
				+ productName + ", productPrice=" + productPrice
				+ ", productQuantity=" + productQuantity + ", description="
				+ description + "]";
	}

}
