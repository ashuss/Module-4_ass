/**************************************************************
File Name   :ProductService.java
Author      :Lalita Gawas
Description :Inteface for ProductServiceImpl with 2 methods defined one for retriving 
              productlist and second for deletion of product from Product. 
Date        :12/10/2017
***************************************************************/
package com.capgemini.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.product.bean.Product;
import com.capgemini.product.dao.IProductDao;

/**
 * @author Lalita
 *
 */
//service class will implements service interface&override all methods
//marking the service class with spring's @Service annotations
@Service
public class ProductService implements IProductService {
	//create Dao interface type variable followed by getters &setters
	//marks the variable with spring's @Autowired annotation
	@Autowired
	IProductDao productDao;

	public IProductDao getProductDao() {
		return productDao;
	}

	public void setProductDao(IProductDao productDao) {
		this.productDao = productDao;
	}

	//------------------------ 1. Product Book --------------------------
	/*******************************************************************************************************
		 - Function Name	:	productList(List<Product>)
		 - Query type	    :   TypedQuery<Product>(dynamic type)
		 - Return Type		:	List<Product> using getResultList
		 - Throws		    :   ProductException
		 - Author		    :    Lalita Suresh Gawas
		 - Creation Date	:	12/10/2017
		 - Description		: Fetching Details from table Product 
	 ********************************************************************************************************/
	@Override
	public List<Product> productList() {
		return productDao.productList();
	}

	//------------------------ 2. Product Book --------------------------
		/*******************************************************************************************************
			 - Function Name	:	deleteProduct(List<Product>)
			 -Input Parameter   :   int id
			 - Query type	    :   TypedQuery<Product>(dynamic type)
			 - Return Type		:	List<Product> using getResultList
			 - Throws		    :   ProductException
			 - Author		    :     Lalita Suresh Gawas
			 - Creation Date	:	12/10/2017
			 - Description		: Deleting Details from table Product 
		 ********************************************************************************************************/
	@Override
	public List<Product> deleteProduct(int id) {

		return productDao.deleteProduct(id);
	}

}
