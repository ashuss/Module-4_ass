/**
 * 
 */
package com.capgemini.product.service;

import java.util.List;

import com.capgemini.product.bean.Product;

/**
 * @author Lalita
 *
 */
public interface IProductService {
	//------------------------ 1. Product Book --------------------------
	/*******************************************************************************************************
		 - Function Name	:	productList(List<Product>)
		 - Query type	    :   TypedQuery<Product>(dynamic type)
		 - Return Type		:	List<Product>
		 - Author		    :     Lalita Suresh Gawas
		 - Creation Date	:	12/10/2017
		 - Description		: Fetching Details from table Product 
	 ********************************************************************************************************/
	public List<Product> productList();
	
	//------------------------ 2. Product Book --------------------------
			/*******************************************************************************************************
				 - Function Name	:	deleteProduct(List<Product>)
				 -Input Parameter   :   int id
				 - Query type	    :   TypedQuery<Product>(dynamic type)
				 - Return Type		:	List<Product> using getResultList
				 - Author		    :     Lalita Suresh Gawas
				 - Creation Date	:	12/10/2017
				 - Description		: Deleting Details from table Product 
			 ********************************************************************************************************/
	public List<Product> deleteProduct(int id);
}
