/**************************************************************
File Name   :ProductException.java
Author      :Lalita Gawas
Description : Userdefined exception for catching Exceptions if any occurs
Date        :12/10/2017
 ***************************************************************/
package com.capgemini.product.exception;

/**
 * @author Lalita
 *
 */
public class ProductException extends Exception {

	/**
	 * default serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	public ProductException() {
		super();
	}

	public ProductException(String message) {
		super(message);
	}

}
