/**************************************************************
File Name   :ProductController.java
Author      :Lalita Gawas
Description :Main controller invoked by various jsp's to perform desired task
Date        :12/10/2017
 ***************************************************************/
package com.capgemini.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.product.bean.Product;
import com.capgemini.product.exception.ProductException;
import com.capgemini.product.service.IProductService;

/**
 * @author Lalita
 *
 */
@Controller
public class ProductController {
	// creating service interface type variable followed by getters &setters
	// marks the variable with spring's @Autowired annotation
	@Autowired
	private IProductService productService;

	public IProductService getProductService() {
		return productService;
	}

	public void setProductService(IProductService productService) {
		this.productService = productService;
	}

	/***********************************************************
	 * Method Name: showViewAllProducts() Return type:ModelAndView
	 * Description:This method returns the list of products that is to be
	 * displayed on the browser otherwise display myError jsp page
	 * 
	 * @author Lalita Gawas
	 ***********************************************************/

	@RequestMapping("/showHomePage")
	public ModelAndView showViewAllProducts() throws ProductException {

		ModelAndView mv = new ModelAndView();
		try{
		List<Product> list = productService.productList();
		if (list.isEmpty()) {
			String msg = "There are no Products.Please insert it";
			mv.setViewName("myError");  //first time display myError.jsp when no data is available
			mv.addObject("msg", msg);

		} else {
			mv.setViewName("viewAllProductsList"); // return view to user
			// Add the attribute to the model
			mv.addObject("list", list);
		}
		} catch (DataAccessException dataAccessException) {
			throw new ProductException(
					"Technical Problem..Please Try Later!!");
		}
		return mv;

	}

	/***********************************************************
	 * Method Name: deleteProducts(int id) Return type:ModelAndView Throws :
	 * ProductException Description:This method delete a product according to id
	 * and display current status of table in same homePage otherwise throws an
	 * ProductException
	 * 
	 * @author Lalita Gawas
	 ***********************************************************/
	@RequestMapping("/deleteProduct")
	public ModelAndView deleteProducts(@RequestParam("id") int id)
			throws ProductException {
		ModelAndView mv = new ModelAndView();
		try {
			List<Product> product = productService.deleteProduct(id);  //deleting product and return current data
			if (product.isEmpty()) {

				throw new ProductException(
						"There are no Products!! List is empty...");
			} else {
				mv.setViewName("viewAllProductsList");
				// Add the attribute to the model
				mv.addObject("list", product);
			}
		} catch (DataAccessException dataAccessException) {
			throw new ProductException(
					"Technical Problem..Please Try Later!!");
		}
		return mv;

	}
}
